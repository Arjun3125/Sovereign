import hashlib


def chunk_hash(book_id: str, chunk_text: str, version: str = "v1") -> str:
    """Return a stable SHA256 hash for a chunk.

    Fingerprint = sha256(book_id + "::" + version + "::" + chunk_text)
    """
    payload = f"{book_id}::{version}::{chunk_text}".encode("utf-8")
    return hashlib.sha256(payload).hexdigest()
