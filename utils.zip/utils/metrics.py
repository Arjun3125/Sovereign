"""Ingest metrics tracking (crash-safe, append-only style).

Tracks progress across ingest runs:
- total_chunks
- completed_chunks
- start_time
- last_update
- percent_complete (computed)
- eta_seconds (computed)
- rate_chunks_per_sec (computed)
"""

import json
import time
from pathlib import Path
from utils.eta import compute_progress

METRICS_FILE = Path("cold_strategist/state/ingest_metrics.json")


def init_metrics(total_chunks: int) -> None:
    """Initialize metrics file at ingest start.
    
    Args:
        total_chunks: Total chunks to ingest (from count before filtering)
    """
    METRICS_FILE.parent.mkdir(parents=True, exist_ok=True)
    
    data = {
        "total_chunks": total_chunks,
        "completed_chunks": 0,
        "start_time": time.time(),
        "last_update": time.time(),
        "percent_complete": 0.0,
        "eta_seconds": None,
        "rate_chunks_per_sec": 0.0,
    }
    
    METRICS_FILE.write_text(json.dumps(data, indent=2))


def update_metrics(chunks_just_done: int = 0) -> None:
    """Update metrics after processing chunks.
    
    Computes ETA and rate from elapsed time.
    
    Args:
        chunks_just_done: Number of chunks just completed
    """
    if not METRICS_FILE.exists():
        return
    
    data = json.loads(METRICS_FILE.read_text())
    data["completed_chunks"] += chunks_just_done
    
    # Compute live progress
    progress = compute_progress(data)
    data.update(progress)
    data["last_update"] = time.time()
    
    METRICS_FILE.write_text(json.dumps(data, indent=2))


def read_metrics() -> dict:
    """Read current metrics (safe to call anytime).
    
    Returns empty dict if file not ready.
    """
    if not METRICS_FILE.exists():
        return {}
    
    try:
        return json.loads(METRICS_FILE.read_text())
    except Exception:
        return {}
