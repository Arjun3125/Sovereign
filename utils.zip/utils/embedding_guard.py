"""GPU-safe embedding with semaphore guard.

Prevents concurrent embedding overload on RTX 4060 (8GB VRAM).

Safe limits:
  - 2 concurrent embeddings (standard)
  - 3 max (not recommended)

Reasoning (LLM) stays single-threaded.
"""

from threading import Semaphore
from typing import List

# RTX 4060 safe concurrent embeddings
GPU_SEMAPHORE = Semaphore(2)


def embed_with_guard(text: str) -> List[float]:
    """Generate embedding with GPU semaphore protection.
    
    Acquires semaphore before calling Ollama embeddings.
    Ensures max 2 concurrent embedding calls on RTX 4060.
    
    Args:
        text: Text to embed
        
    Returns:
        Embedding vector (768-dim for nomic-embed-text)
    """
    from ollama import embeddings
    
    with GPU_SEMAPHORE:
        response = embeddings(
            model="nomic-embed-text",
            prompt=text
        )
        return response["embedding"]
